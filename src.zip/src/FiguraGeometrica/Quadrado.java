package FiguraGeometrica;

public class Quadrado extends FiguraGeometrica {
        public void calcularArea() {
        	double lado = 5.0;
        	double Area = lado * lado;
        System.out.println("Área do quadrado: " + Area);
        }
        public void calcularPerimetro() {
        	double lado = 5.0;
        	double Perimetro = 4 * lado;
        System.out.println("Perímetro do quadrado: " + Perimetro);
        }
}
    
	