package FiguraGeometrica;

public class Circulo extends FiguraGeometrica {
	    public void calcularArea() {
	    	double raio = 5.0;
	 	    double Area = PI * raio;
		System.out.println("Área do círculo: " + Area);
	    }
	    public void calcularPerimetro() {
	    	 double raio = 5.0;
	    	 double Perimetro = 2 * PI * raio;
		System.out.println("Perímetro do círculo: " + Perimetro);
	    } 
	}


