package FiguraGeometrica;

public abstract class FiguraGeometrica {
 static double PI = 3.1415; 
 public abstract void calcularArea();
 public abstract void calcularPerimetro();
 
}
