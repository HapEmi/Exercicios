package FiguraGeometrica;

public class Teste {

	public static void main(String[] args) {
		Quadrado quadrado = new Quadrado();
		Circulo circulo = new Circulo();
		
		circulo.calcularArea();
		quadrado.calcularArea();
		quadrado.calcularPerimetro();
		circulo.calcularPerimetro();

	}

}
