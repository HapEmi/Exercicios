package Veiculo;

public class Moto extends Veiculo {
	public void Acelerar() {
		System.out.println("A moto acelerou");
	}
    public void Frear() {
    	System.out.println("A moto freou");
    }
}
