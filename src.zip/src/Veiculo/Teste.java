package Veiculo;

public class Teste {

	public static void main(String[] args) {
		Moto moto = new Moto();
		Carro carro = new Carro();
		
		carro.Frear();
		moto.Frear();
		carro.Acelerar();
		moto.Acelerar();
		
	}

}
