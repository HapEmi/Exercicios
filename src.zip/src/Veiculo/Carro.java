package Veiculo;

public class Carro extends Veiculo {
	public void Acelerar() {
		System.out.println("O carro acelerou");
	}
	public void Frear() {
		System.out.println("O carro Freou");
	}
	

}
