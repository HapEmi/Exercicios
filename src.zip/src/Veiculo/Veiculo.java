package Veiculo;

public abstract class Veiculo {
	public abstract void Acelerar();
	public abstract void Frear();

}