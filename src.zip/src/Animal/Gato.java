package Animal;

public class Gato extends Animal {
	public void EmitirSom() {
		System.out.println("Gato: Meow meow meow");
	}

}
