package Animal;

public class Passaro extends Animal {
	public void EmitirSom() {
		System.out.println("Pássaro: Piu piu piu");
	}

}
