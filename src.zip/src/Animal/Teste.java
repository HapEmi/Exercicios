package Animal;

public class Teste {

	public static void main(String[] args) {
		Cachorro cachorro = new Cachorro();
		Gato gato = new Gato();
		Passaro passaro = new Passaro();
		
		cachorro.EmitirSom();
		gato.EmitirSom();
		passaro.EmitirSom();

	}

}
