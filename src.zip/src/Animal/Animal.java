package Animal;
public abstract class Animal {
		public void EmitirSom() {
		System.out.println("Este animal faz esse som: ");

		}
}


