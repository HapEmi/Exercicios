package Animal;

public class Cachorro extends Animal {
	public void EmitirSom() {
		super.EmitirSom();
		System.out.println("Cachorro: Au au au");
	}

}
