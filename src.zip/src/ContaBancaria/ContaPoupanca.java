package ContaBancaria;

public class ContaPoupanca extends ContaBancaria {
	public void Depositar() {
		 System.out.println("Depositou dinheiro na conta poupança");
	 }
	 public void Sacar() {
		 System.out.println("Você sacou o dinheiro da conta poupança");
			


	}

}
