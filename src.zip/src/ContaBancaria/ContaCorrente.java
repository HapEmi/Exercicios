package ContaBancaria;

public class ContaCorrente extends ContaBancaria {
 public void Depositar() {
	 System.out.println("Depositou dinheiro na conta corrente");
 }
 public void Sacar() {
	 System.out.println("Você sacou o dinheiro da conta corrente");
		

	}

}
