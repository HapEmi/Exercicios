package ContaBancaria;

public class Teste {

	public static void main(String[] args) {
		ContaPoupanca contapoupanca = new ContaPoupanca();
		ContaCorrente contacorrente = new ContaCorrente();
		
		contapoupanca.Depositar();
		contacorrente.Depositar();
		contapoupanca.Sacar();
		contacorrente.Sacar();

	}

}
