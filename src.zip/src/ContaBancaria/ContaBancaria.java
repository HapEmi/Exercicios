package ContaBancaria;

public abstract class ContaBancaria {
 public abstract void Depositar();
 public abstract void Sacar();
}
