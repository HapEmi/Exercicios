package Pessoa;

public class Teste {

	public static void main(String[] args) {
		Professor professor = new Professor();
		Aluno aluno = new Aluno();
		
		professor.Andar();
		aluno.Andar();
		professor.Falar();
		aluno.Falar();
		
	}

}
