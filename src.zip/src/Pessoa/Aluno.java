package Pessoa;

public class Aluno extends Pessoa {
	public void Andar() {
		 System.out.println("O aluno andou pela quadra de futebol");
	}
	public void Falar() {
		System.out.println("O aluno falou pro amigo que não iria para a aula");
 }
}
