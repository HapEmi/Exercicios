package Pessoa;

public class Professor extends Pessoa {
public void Andar() {
	 System.out.println("O professor andou pelo corredor");
}
public void Falar() {
	System.out.println("O professor falou para a sala de aula");
}
 }
	

