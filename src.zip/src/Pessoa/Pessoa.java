package Pessoa;

public abstract class Pessoa {
 public abstract void Falar();
 public abstract void Andar();
}
